<?php

$servidor ="localhost";
$usuario = "root";
$senha = "";
$dbname="informacoes";

//Conexão

$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);


if($conn->connect_errno){
	echo "Erro";
	
}

else
{
	echo "Conexão estabelecida";
	
}

?>